# Rias Gremory custom species

Species ID: 1578 (SPECIES_RIAS_GREMORY)
Type: DEMON (new type ID 21)
Gender: Female only
No evolution / undiscovered egg group
Legendary-tier BST: 680 (HP 100 / Atk 80 / Def 90 / SpA 160 / SpD 120 / Spe 130)
Ability: Crimson Demon - 1.3333x special Demon-type damage

Custom Demon moves (13): Demon Bolt, Crimson Ruin, Power of Destruction, Devil's Gaze, Hellfire Lance, Demonic Pulse, Crimson Ward, Devil's Recovery, Infernal Step, Nightmare Crown, Destruction Wave, Scarlet Judgment, Gremory Apocalypse.

Early gift: Mom gives Lv.5 Rias during the opening New Bark Town house introduction, immediately after Pokegear/Running Shoes sequence. Flag FLAG_RECEIVED_RIAS_GREMORY prevents duplicates.

Graphics: front/back/icon/palettes prepared from supplied reference sheet. Type icon currently reuses Dark/Mystery visual assets until a dedicated Demon type-icon sheet is drawn. Cry temporarily uses Miraidon. Pokedex intentionally deferred.

Build status: source changes prepared, but this environment lacks arm-none-eabi GCC/binutils, so no tested .gba can be produced here.
